public interface PortableDevice {
    
    public String getModel();
    public int getBatteryCapacity();
}
